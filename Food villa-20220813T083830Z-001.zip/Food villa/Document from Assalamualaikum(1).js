let carts=document.querySelectorAll('.add-cart');
let products=[
    {
        name : 'Biryani',
        tag : 'https://wallpaperaccess.com/full/4622434.jpg',
        price : 350,
        inCart :0
    },
    {
        name : 'Burger',
        tag : 'images/menu-2.avif',
        price : 150,
        inCart :0
    },
    {
        name : 'Pizza',
        tag : 'images/menu-3.jpg',
        price : 200,
        inCart :0
    },
    {
        name : 'Breakfast',
        tag : 'images/menu-4.jpg',
        price : 100,
        inCart :0
    },
    {
        name : 'Meals',
        tag : 'images/menu-5.jpg',
        price : 200,
        inCart :0
    },
    {
        name : 'Chinese',
        tag : 'images/menu-6.jpg',
        price : 150,
        inCart :0
    },
    {
        name : 'Thai',
        tag : 'images/menu-7.jpg',
        price : 200,
        inCart :0
    },
    {
        name : 'Mocktail',
        tag : 'https://wallpaperaccess.com/full/3442785.jpg',
        price : 100,
        inCart :0
    },
    {
        name : 'Coffee',
        tag : 'images/menu-9.webp',
        price : 120,
        inCart :0
    }
];

for(let i=0;i<carts.length;i++){
    carts[i].addEventListener('click', () => {
        cartNumbers(products[i]);
        totalcost(products[i])
   })
}

function onLoadCartNumbers(){
    let productNumbers=localStorage.getItem('cartNumbers');

    if(productNumbers){
        document.querySelector('.cart span').textContent = productNumbers;
    }
}

function cartNumbers(product){
    let productNumbers=localStorage.getItem('cartNumbers');
    productNumbers=parseInt(productNumbers);
    if(productNumbers){
        localStorage.setItem('cartNumbers',productNumbers + 1);
        document.querySelector('.cart span').textContent = productNumbers + 1;
     }
    else{
         localStorage.setItem('cartNumbers',1);
         document.querySelector('.cart span').textContent = 1;
     }

     setItems(product);
}

function setItems(product){
    let cartItems=localStorage.getItem("ProductsInCart");
    cartItems=JSON.parse(cartItems);

    if(cartItems != null){
        if(cartItems[product.tag] == undefined) {
            cartItems={
                ...cartItems,
                [product.tag]:product
            }
        }
        cartItems[product.tag].inCart +=1;
    }
    else{
        product.inCart =1;
        cartItems={
            [product.tag]:product
        }
    }
    
    localStorage.setItem("ProductsInCart", JSON.stringify
    (cartItems));
}

function totalcost(product){
    // console.log("The product price is :",product.price);
    let cartCost=localStorage.getItem("totalCost");
    
    console.log("Total cart cost is :",cartCost);
    console.log(typeof cartCost);
    
    if(cartCost  != null){
        cartCost=parseInt(cartCost);
        localStorage.setItem("totalCost", cartCost + product.price);
    }
    else{
        localStorage.setItem("totalCost",product.price);
    }

}

function displayCart(){
    let cartItems=localStorage.getItem("ProductsInCart");
    cartItems=JSON.parse(cartItems);
    let productContainer=document.querySelector(".products");
    let cartCost=localStorage.getItem("totalCost");
    if(cartItems && productContainer){
        productContainer.innerHTML = '';
        Object.values(cartItems).map(item => {
            productContainer.innerHTML += `
            <div class="product">
            
                <img src="${item.tag}.jpg">
            <span>${item.name}</span>
        </div>
            <div class="price">$${item.price}.00</div>
            <div class="quantity">
                ${item.inCart}
            </div>
            <div class="total">
            $${item.inCart * item.price}.00
            </div>

        `;
    });

    productContainer.innerHTML +=`
        <div class="basketTotalContainer">
        <h4 class="basketTotalTitle">
        Basket Total
        </h4>
        <h4 class="basketTotal">
        $${cartCost}.00
        </h4>
        </div>
        <div>
        <button class="basketPay" >Order</button>
        </div>
    `;
}
}

onLoadCartNumbers();
displayCart();